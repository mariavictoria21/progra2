/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package f.primerobj_mariareyes;

/**
 *
 * @author Maria Reyes
 */
public class Principal {
    public static void main(String[] args) {
        // Crear un objeto de la clase Auto
        Auto miAuto = new Auto("Toyota", "Rojo", "Sedán", "Corolla", 5);

        // Configurar los valores de los atributos
        miAuto.setMarca("Honda");
        miAuto.setColor("Azul");
        miAuto.setTipo("SUV");
        miAuto.setModelo("CR-V");
        miAuto.setCantidadPasajeros(7);

        // Mostrar la información del objeto
        miAuto.mostrarInformacion();
    }
}